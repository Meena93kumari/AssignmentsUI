function validatefirstname() {
	var name = document.getElementById("firstname").value;
	if (name === "") {
		alert("first name is mandatory");
		return false;
	}
	return true;
}

function validatePaddress() {
	var name = document.getElementById("PAddress").value;
	if (name === "") {
		alert("Present addresee  is mandatory");
		return false;
	}
	return true;
}



function usecheckbox() {
	var permanentaddress = document.getElementById("PAddress").value;
	var checkbox = document.getElementById("checkbox").value;
	if (checkbox == true)
		usecheckbox();
	if (checkbox == true) {
		document.getElementById("CAddress").value = permanentaddress;
	}

}


function validatephone() {
	var phone = document.getElementById("phone").value;
	var phonelen = phone.length;
	console.log(phonelen + "Hi" + phone);
	if (phonelen != 10) {
		alert("invalid mobile no");

		return false;
	}

	return true;
}

function validateemail() {

	var emailid = document.getElementById("Email");
	var pattern = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	if (emailid.value.match(pattern)) {
		return true;
	} else {
		alert("invalid email");
		return false;
	}
}

function validatepassword() {
	var pass = document.getElementById("Password").value;
	if (pass.length < 8) {
		alert("password must be of atleast 8 characters");

		return false;
	}

	return true;
}

function validateconfirmpassword() {

	var pass1 = document.getElementById("Password").value;
	var pass2 = document.getElementById("Confirm").value;
	if (pass1 != pass2) {
		alert("passwords not matching");
		return false;
	}
	return true;
}



function allvalidation() {
	var is = true;
	if (validatefirstname() == false)
		is = false;;
	if (validatefirstname() == false)
		is = false;
	if (validatePaddress() == false)
		is = false;
	//usecheckbox();
	if (validateemail() == false)
		is = false;
	if (validatephone())
		is = false;

	if (validatepassword() == false)
		is = false;

	if (validateconfirmpassword() == false)
		is = false;
	//usecheckbox();
	return is;
}

function append() {

	var first = document.getElementById('firstname').value;
	var last = document.getElementById('lastname').value;
	document.getElementById('dashboard').innerHTML = first;
}

function resetvalues() {
	document.getElementById('firstname').value = '';
	document.getElementById("lastname").value = "";
	document.getElementById("PAddress").value = "";
	document.getElementById("check").checked = false;
	document.getElementById("CAddress").value = "";
	document.getElementById("Email").value = "";
	document.getElementById("phone").value = "";
	document.getElementById("Password").value = "";
	document.getElementById("Confirm").value = "";
}

window.onload = function() {
	/*document.getElementById("Registeration").onclick = function() {
		usecheckbox();
	}*/
	document.getElementById("Register").onclick = function() {
		if (allvalidation() == true) {
			append();
			//usecheckbox();
		}
	}
	document.getElementById("reset").onclick = function() {
		resetvalues();
	}
}