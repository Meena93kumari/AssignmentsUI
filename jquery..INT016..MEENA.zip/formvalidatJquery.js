$(document).ready(function() {
	$("#firstname").blur(function() {
		var name = $(this).val();
		if (name === "") {
			alert("First name is mandatory");

		}

	});

	$("#PAddress").blur(function() {
		var add = $(this).val();
		if (add === "") {
			alert("Present address  is mandatory");
		}
	});

	$("#check").click(function() {
		var pval = $("#PAddress").val();
		$("#CAddress").val(pval);
	});


	$("#Email").blur(function() {
		var pattern = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		var emailid = $(this).val();
		console.log(emailid.match(pattern));
		if (emailid.match(pattern) === null) {
			alert("invalid email");
		}

	});


	$("#phone").blur(function() {
		var value = $(this).val().length;
		console.log(value);
		if (value != 10) {
			alert("invalid mobile no");
		}
	});



	$("#Password").blur(function() {
		var value = $(this).val();
		if (value.length < 8) {
			alert("password must be of atleast 8 characters");
		}
	});
	$("#Confirm").blur(function() {
		var pval = $("#Password").val();
		var cval = $("#Confirm").val();
		if (cval != pval) {
			alert("passwords not matching");
		}
	});

	$("#ResetForm").click(function() {
		$("#appform").trigger("reset");
	});

	$("#Register").click(function() {
		var ul = $('#dashboard');
		var firstName = $('#firstname').val();
		var lastName = $('#lastname').val();
		var email = $("#Email").val();
		var li = $("<li></li>", {
			class: "dashboard-content"

		});

		var a = $("<div></div>", {
			class: "dashboard-content-fname"
				//href: "#"
		}).text(firstName + " " + lastName);

		var div = $("<a></a>", {
			class: "dashboard-content-email"

		}).text(email);

		li.append(a);
		ul.append(li);
		li.append(div);


	});


});