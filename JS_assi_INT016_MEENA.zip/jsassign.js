//ques1.a:
var companyName;
//ques1.b:
var goodTeamMember = "Meena";
//ques1.c
var number1 = 3;
var number2 = 5;
console.log(number1 * number2);
//ques1.d
var country = "India";
country = "USA";
country = "Singapore";
console.log(country);
//ques1.e
var u_name = "Meena Kumari";
var college_name = "IIT(ISM)";
console.log("u_name:" + u_name);
console.log("college_name:" + college_name);
//ques2.a
console.log(typeof("Ram"));
//ques2.b
console.log(typeof(false));
//ques2.c
console.log(typeof(-23) === "number");
//ques2.d
console.log(typeof(typeof(33)));
//ques3.a
var myname = "Meena";
var friendname = "Esha";
var older; //1 for me ,2 for frnd,3 when same age
var date_mine = {
	Day: 24,
	Month: 6,
	Year: 1993
};
var date_frnd = {
	Day: 11,
	Month: 12,
	Year: 1995
};
if (date_mine.Year === date_frnd.Year) {
	if (date_mine.Month === date_frnd.Month) {
		if (date_mine.Day < date_frnd.Day) {
			older = 1;
		} else if (date_mine.Day < date_frnd.Day) {
			older = 2;
		} else {
			older = 3;
		}

	} else if (date_mine.Month < date_frnd.Month) {
		older = 1;
	} else {
		older = 2;
	}

} else if (date_mine.Year < date_frnd.Year) {
	older = 1;
} else {
	older = 2;
}
if (older === 1) {
	console.log(myname);
} else if (older === 2) {
	console.log(friendname);
} else {
	console.log(friendname + " " + myname);
}
//ques3.b
var alpha = function(a) {

	switch (a) {
		case 'a':
			{
				return "vowel";
				break;
			}
		case 'e':
			{
				return "vowel";
				break;
			}
		case 'i':
			{
				return "vowel";
				break;
			}
		case 'o':
			{
				return "vowel";
				break;
			}
		case 'u':
			{
				return "vowel";
				break;
			}
		default:
			{
				return "consonant";
				break;
			}
	}

}
console.log(alpha('a'));
console.log(alpha('b'));
//ques 4.a

function display(m) {
	var n = m[0].length;
	for (var r = 0; r < m.length; ++r) {
		for (j = 0; j < n; j++) {
			if (m[r][j] == 0)
				document.write('&nbsp');
			document.write(m[r][j] + " ");
		}
		document.write('</br>');
	}
}



var printpascal = function(n) {
	var twodarr = [];
	for (i = 0; i < n; i++) {
		twodarr[i] = [];
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < 2 * n - 1; j++)
			twodarr[i][j] = 0;
	}

	twodarr[0][n - 1] = 1;

	for (i = 1; i < n; i++) {
		for (j = 0; j < 2 * n - 1; j++) {
			if (j === 0) {
				twodarr[i][j] = twodarr[i - 1][j + 1];

			} else if (j === 2 * n - 2)
				twodarr[i][j] = twodarr[i - 1][j - 1];

			else {
				twodarr[i][j] = twodarr[i - 1][j - 1] + twodarr[i - 1][j + 1];
			}
		}

	}
	twodarr[n - 1][0] = 1;
	twodarr[n - 1][n - 1] = 1;
	/*for (i = 0; i < n; i++) {

		for (j = 0; j < 2 * n - 1; j++) {

			if (twodarr[i][j] === 0)
				document.write(" &nbsp ");
			else document.write(twodarr[i][j]);


		}

		document.write('</br');
	}*/

	display(twodarr);
}
printpascal(5);
//ques4.b
var matrix1 = [
	[1, 0],
	[0, 1]
];
var matrix2 = [
	[2, 3],
	[4, 5]
];
var multiplymat = function(matrix1, matrix2) {
	var r1 = matrix1.length;
	var c1 = matrix1[0].length;
	var r2 = matrix2.length;
	var c2 = matrix2[0].length;
	var matrix3 = [];
	for (i = 0; i < r1; i++) {
		matrix3[i] = [];
		for (j = 0; j < c2; j++) {
			matrix3[i][j] = 0;
			for (k = 0; k < c1; k++) {
				matrix3[i][j] = matrix3[i][j] + matrix1[i][k] * matrix2[k][j];
			}

		}
	}
	display(matrix3);

}
multiplymat(matrix1, matrix2);

//ques5 .a
function rev(s1) {
	if (typeof(s1) === Number) {
		var res = 0;
		while (s1 > 0) {
			res = (res * 10) + (s1 % 10);
			s1 = parseInt(s1 / 10);
		}

		return res;
	} else {
		var i = 0;
		var j = s1.length - 1;

		/*while (i < j) {
			var temp1 = s1.charAt(i);
			/*var temp1 = s1[i];
			s1[i] = s1[j];
			s1[j] = temp1;

			var temp2 = s1.charAt(j);
			s1.replace(s1.charAt(i), temp2);
			s1.replace(s1.charAt(j), temp1);
			i = i + 1;
			j = j - 1;

		}*/
		var resstr = "";
		for (k = j; k >= 0; k--) {
			resstr = resstr + s1[k];

		}

		return resstr;
	}

}
document.write(rev("mna"));

//ques5.b
var ispalindrome = function(s1) {
	var len = s1.length;
	var i = 0;
	var j = len - 1;
	while (i < j) {
		if (s1.charAt(i) != s1.charAt(j))
			return false;
		i = i + 1;
		j = j - 1;
	}

	return true;

}
console.log(ispalindrome("aba"));
console.log(ispalindrome("abb"));
//ques5.c
var firstnonrepeat = function(s) {
	var count = [];
	for (i = 0; i < s.length; i++) {
		count[s.charAt(i)] = 0;
	}
	for (i = 0; i < s.length; i++) {
		count[s.charAt(i)] = count[s.charAt(i)] + 1;
	}


	for (j = 0; j < s.length; j++) {
		if (count[s.charAt(j)] === 1)
			return (s.charAt(j));
	}


}
console.log(firstnonrepeat("xxydym"));
//ques 6
var student = {
	Name: "Meena",
	Address: "Pune",
	Department: "IT",
	Mobile: "9799548980"
};
console.log(rev(student.Name));

//ques7.a
var patt = "/\d/i";
var str = "I am 25 years old. I was born in 1991.";

function arrpatt(str) {

	var p = (str.match(/\d+/g));
	for (i = 0; i < p.length; i++) {
		p[i] = parseInt(p[i]);
	}
	return p;

}
console.log(arrpatt(str));
//ques7.b
var emailvalidity = function(str) {
	var patt = /^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_.-])+\.([a-zA-Z])+([a-zA-Z])+([a-zA-Z])/;
	if (patt.test(str))
		return true;
	return false;

}
console.log(emailvalidity("meenadukiya@gmail.com"));
//ques 8
var isbalanced = function(str) {
	var stack = [];
	var i;
	for (i = 0; i < str.length; i++) {
		if (str[i] === '[' || str[i] === '(' || str[i] === '<') {
			stack.push(str[i]);
		}
		if (str[i] === ']' || str[i] === ')' || str[i] === '>') {
			var pop = stack.pop(str[i]);
			if (str[i] == '(')
				if (pop != ')')
					return false;

			if (str[i] == '[')
				if (pop != ']')
					return false;

			if (str[i] == '<')
				if (pop != '>')
					return false;

		}


	}

	if (stack.length >= 1)
		return false;
	return true;
}
console.log(isbalanced("(([]))"));